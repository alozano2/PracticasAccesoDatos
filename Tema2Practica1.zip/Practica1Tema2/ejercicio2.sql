--Ejercicio2: Crear un tipo Persona con los atributos: C�digo number, nombre varchar(35), direc de tipo Direccion y fecha_nac date. 
CREATE OR REPLACE TYPE people AS OBJECT (
  C�digo NUMBER,
  nombre VARCHAR2(35),
  direc Direcci�n, 
  fecha_nac DATE
);