--Ejercicio4: Crear una tabla alumnos de tipo persona, y en ella: 
CREATE TABLE alumnos OF people;

--a) Insertar dos alumnos.
-- Insertar el primer alumno
INSERT INTO alumnos VALUES (
    people(1, 'Juan Pedro', Direcci�n('Calle Moral', 'Madrid', 28004), TO_DATE('13-02-96')));
    
-- Insertar el segundo alumno
INSERT INTO alumnos VALUES (
    people(2, 'Maria Luisa', Direcci�n('Calle Loren', 'Madrid', 28003), TO_DATE('09-01-93')));
    
-- Insertar el tercer alumno
INSERT INTO alumnos VALUES (
    people(2, 'Maria Jose', Direcci�n('Calle Loren', 'Guadalajara', 28003), TO_DATE('09-01-93')));

--b) Seleccionar las filas cuya ciudad sea Guadalajara. 
SELECT * FROM alumnos WHERE Direcci�n.ciudad = 'Guadalajara';

--c) Seleccionar c�digo, Direc(columna de tipo objeto) de los alumnos. 
SELECT C�digo, direc FROM alumnos;

--d) Modificar las filas cuya ciudad sea Guadalajara y convertir la ciudad a min�scula. 
UPDATE alumnos
SET direc.ciudad = LOWER(direc.ciudad)
WHERE direc.ciudad = 'Guadalajara';

--e) Crear un bloque PL que muestre el nombre y la calle de los alumnos. 
DECLARE
    v_nombre VARCHAR2(50);
    v_calle VARCHAR2(100);
BEGIN
    -- Utilizar un cursor para seleccionar los nombres y calles de los alumnos
    FOR rec IN (SELECT nombre, direc.calle FROM alumnos) LOOP
        v_nombre := rec.nombre;
        v_calle := rec.calle;
        
        -- Mostrar los datos
        DBMS_OUTPUT.PUT_LINE('Nombre: ' || v_nombre);
        DBMS_OUTPUT.PUT_LINE('Calle: ' || v_calle);
        DBMS_OUTPUT.PUT_LINE('-----------------');
    END LOOP;
END;
/

--f) Eliminar aquellas filas cuya ciudad sea Guadalajara. 
BEGIN
    DELETE FROM alumnos
    WHERE direc.ciudad = 'Guadalajara';
    COMMIT;
END;
/
