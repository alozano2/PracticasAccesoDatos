DECLARE
    dir Direcci�n := Direcci�n(NULL, NULL, NULL);
    P Persona := PERSONA (NULL, NULL, NULL, NULL);
BEGIN
    DIR.CALLE := 'La mina, 3';
    DIR.CIUDAD := 'Guadalajara';
    DIR.C�DIGO_POST := 19001;
    P.C�DIGO := 1;
    P.NOMBRE := 'JUAN';
    P.DIREC := DIR;
    P.FECHA_NAC := TO_DATE('10-11-1998');
    END;
/