
--Ejercicio1: Crear un tipo Direcci�n con los atributos calle varchar(25), ciudad varchar(20),  y c�digo_post number(5). 
CREATE OR REPLACE TYPE Direcci�n AS OBJECT (
  calle VARCHAR2(25),
  ciudad VARCHAR2(20),
  c�digo_post NUMBER(5)
);








